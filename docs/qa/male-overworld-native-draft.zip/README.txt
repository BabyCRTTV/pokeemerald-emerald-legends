Pokémon Emerald: Legends — male overworld review draft

80 indexed PNG sheets, actual compiled field output at native resolution.
Natural hair, first skin tone, Emerald outfit, no accessories.
Walking sheets contain 18 native walking/running frames in runtime order.
Other sheets use the native image-table order; east is mirrored by native animations.
These PNGs are review/export assets. ROM integration uses heads.png, the
pose-local edits.bin/style_layers.h bank and the existing C compositor.
Artwork requires owner approval; published VERSION remains 0.0.46.
